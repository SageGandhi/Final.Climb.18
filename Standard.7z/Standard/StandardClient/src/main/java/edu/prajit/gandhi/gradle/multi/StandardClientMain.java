package edu.prajit.gandhi.gradle.multi;

public class StandardClientMain {
	public static void sayHello(String message) {
		System.out.println(StandardClientMain.class.getName()+message);
		StandardUtilityMain.sayHello("Calling From "+StandardClientMain.class.getName());
		StandardJaxbGeneratedMain.sayHello("Calling From "+StandardClientMain.class.getName());
	}
}
