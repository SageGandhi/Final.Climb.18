package edu.prajit.gandhi.gradle.multi;

public class StandardJaxbGeneratedMain {
	public static void sayHello(String message) {
		System.out.println(StandardJaxbGeneratedMain.class.getName()+message);
	}
}
