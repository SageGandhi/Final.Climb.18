package edu.prajit.gandhi.gradle.multi;

public class StandardUtilityMain {
	public static void sayHello(String message) {
		System.out.println(StandardUtilityMain.class.getName()+message);
		StandardJaxbGeneratedMain.sayHello("Calling From "+StandardUtilityMain.class.getName());
	}
}
